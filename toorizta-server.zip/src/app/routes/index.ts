import { Router } from "express";
import { AuthRoutes } from "../modules/auth/auth.route";
import { UiRoutes } from "../modules/ui/ui.route";
import { UserROutes } from "../modules/users/user.route";
import { AdminRoutes } from "../modules/admin/admin.route";
import { SpotRoutes } from "../modules/spot/spot.route";
import { BookingRoutes } from "../modules/booking/booking.route";
// import { AdminRoutes } from "../modules/admin/admin.route";

const router = Router();

const moduleRoutes = [
  {
    path: "/auth",
    route: AuthRoutes,
  },
  {
    path: "/user",
    route: UserROutes,
  },
  {
    path: "/admin",
    route: AdminRoutes,
  },
  {
    path: "/ui",
    route: UiRoutes,
  },
  {
    path: "/spot",
    route: SpotRoutes,
  },
  {
    path: "/booking",
    route: BookingRoutes,
  },
];

moduleRoutes.forEach((route) => router.use(route.path, route.route));

export default router;
